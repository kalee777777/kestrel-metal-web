KESTREL GATE HARDWARE CAD MODELS
=================================

Contents:
  gate-hinge-km-gh-160.dxf     Adjustable gate hinge, plan view, mm units
  security-lock-km-sl-2c.dxf   Double-cylinder security lock, front view, mm units

Format: AutoCAD DXF R12 (ASCII), units = millimeters.
Layers:
  0      - component outline
  HOLES  - fixing holes

Notes:
  - Hinge rated 160 kg per pair; lock keyed-alike sets available.
  - 3D STEP models of these components available from engineering on request.

Kestrel Metal Industrial Co., Ltd. - www.kestrelmetal.com
Document KM-CAD-003, Rev.2, 2024-03
