KESTREL FENCE PANEL CAD LIBRARY
================================

Contents:
  panel-3d-2030x2400.dxf   3D panel 2030 x 2400 mm, wire 5/6, mesh 50x200, 4 V-beams
  panel-3d-2500x2500.dxf   3D panel 2500 x 2500 mm, wire 5/6, mesh 50x200, 5 V-beams
  panel-3d-2030x3300.dxf   3D panel 2030 x 3300 mm, wire 6/7, mesh 50x200, 7 V-beams

Format: AutoCAD DXF R12 (ASCII), units = meters (scale 1:100 of mm drawing).
Layers:
  0      - outline and V-beam bends
  MESH   - mesh grid lines (50 x 200 mm)

Notes:
  - DXF opens in AutoCAD, BricsCAD, LibreCAD, SketchUp (import), Revit (import).
  - For DWG conversion use any DXF->DWG translator; geometry is R12-safe.
  - Full parametric models and STEP files available from engineering on request.

Kestrel Metal Industrial Co., Ltd. - www.kestrelmetal.com
Document KM-CAD-001, Rev.2, 2024-03
